package semiproyecto;

public enum TipoEnum {
    Preferencial, UnTramite, MasTramites, Vacio
}
