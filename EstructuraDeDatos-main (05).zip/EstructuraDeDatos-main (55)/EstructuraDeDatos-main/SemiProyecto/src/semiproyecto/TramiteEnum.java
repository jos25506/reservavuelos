package semiproyecto;

public enum TramiteEnum {
    Deposito, Retiro, CambioDivisas, Vacio
}
